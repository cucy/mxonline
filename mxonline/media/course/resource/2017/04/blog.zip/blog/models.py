# -*- coding: utf-8 -*-
# __author__ = 'zhourudong'

from m.extensions.sqlalchemy import  SQLAlchemy
from sqlalchemy import Column, Integer, String,DateTime, ForeignKey, UniqueConstraint,Text
from sqlalchemy.orm import relationship

db = SQLAlchemy(config_prefix='database')

# 定义user表
class User(db.Model):
    __tablename__ = 'user'
    id =Column(Integer, primary_key=True, autoincrement=True)
    nickname = Column(String(45), unique=True, nullable=False) #昵称
    email = Column(String(64), unique=True, nullable=False)
    password =Column(String(64), nullable=False)

    catalogs = relationship('Catalog', foreign_keys='[Catalog.user_id]')

# Catalog 分类
class Catalog(db.Model):
    __tablename__ = 'catalog'
    __table_args__ = (UniqueConstraint('user_id', 'name', name='uq_catalog_user_name')) # 联合唯一索引
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey('user.id'), nullable=False) # 外键为user的id
    name = Column(Integer, nullable=False)

# 文章内容
class Post(db.Model):
    __tablenam__ = 'post'

    id = Column(Integer, primary_key=True, autoincrement=True)
    title  = Column(String(192), nullable=False, )
    author_id = Column(Integer, ForeignKey('user.id'), nullable=False)
    catalog_id = Column(Integer, ForeignKey('catalog.id'), nullable=False)
    timestamp = Column(DateTime, nullable=False)
    status = Column(Integer, nullable=False, default=0)  # 0 为草稿
    read_conut = Column(Integer, nullable=False, default=0)

    author = relationship('User', foreign_keys= [author_id])  # 关联关系
    catalog = relationship('Catalog', foreign_keys= [catalog_id])
    content = relationship('PostContent', foreign_keys= '[PostContent.id]')  # 外键在别的表所以需要引号


class PostContent(db.Model):
    __tablename__ = 'post_content' # 文章内容

    id = Column(Integer, ForeignKey('post.id|'), primary_key=True)
    content = Column(Text, nullable=False)

    # 建立关系

# 收藏
class Favorite(db.Model):
    __tablename__ = 'favorite'

    user_id = Column(Integer ,ForeignKey('user.id'), primary_key=True)
    post_id = Column(Integer, ForeignKey('post.id'), primary_key=True)

# like
class Like(db.Model):
    __tablename__ = 'like'

    user_id = Column(Integer ,ForeignKey('user.id'), primary_key=True)
    post_id = Column(Integer, ForeignKey('post.id'), primary_key=True)


# 评论
class Comment(db.Model):
    __tablename__ = 'comment'

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey('user.id'), nullable=False)
    post_id = Column(Integer, ForeignKey('post.id'), nullable=False)
    ref_id = Column(Integer, ForeignKey('comment.id'), nullable=True)
    content = Column(String(420), nullable=False)
    timestamp = Column(DateTime, index=True, nullable=False)  # 时就顺序进行排序

    # 关系
    user = relationship('User', foreign_keys=[user_id])
    ref = relationship('Comment', foreign_keys=[ref_id])